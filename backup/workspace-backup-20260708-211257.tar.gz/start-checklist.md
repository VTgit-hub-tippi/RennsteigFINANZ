# Start-Checkliste

1. Claude Code starten.
2. Falls lokale Skills nicht sofort sichtbar sind, Claude neu starten oder `/reload-plugins` ausführen.
3. Einen einfachen Testprompt senden, zum Beispiel:
   - "Fasse dieses Projekt in 6 Bulletpoints zusammen."
   - "Prüfe diesen Codeabschnitt mit dem lokalen Review-Skill."
4. Kontextbudget beobachten: bei ca. 60-70% immer geplanter Neustart mit Pflichtfolge
   - zuerst `/context-snapshot`
   - dann Neustart
   - danach `/context-restore`
5. Nutzungsseite parallel offen halten und Verbrauch regelmaessig pruefen:
   - `https://claude.ai/new#settings/usage`
6. Modell bewusst waehlen (`/model`):
   - mindestens Sonnet
   - fuer komplexes Coding bevorzugt Opus
7. Prompt immer mit klarem Ziel und Scope starten; bei Datei-Checks betroffene Datei(en) explizit nennen.
8. Rueckfragen aktiv einfordern; Arbeitsfolge sichtbar halten: Anforderungen -> Spezifikation -> Plan -> Umsetzung -> Tests.
9. Bei groesseren Coding-Aufgaben Sub-Agents gezielt fuer Parallelisierung und Token-Effizienz nutzen.
10. Bei Bedarf die Eval-Dateien in [evals/README.md](evals/README.md) verwenden.
