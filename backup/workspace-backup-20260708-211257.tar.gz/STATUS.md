# STATUS.md — Wöchentliches Betriebslogbuch

> **Dies ist das lebende Gedächtnis des Betriebs.** Jede Session beginnt hier, jede Session endet hier aktualisiert.
> 
> Update-Frequenz: Nach jeder Session / täglich / wöchentlich (je nach Intensität)

---

## 📅 Aktueller Stand (Woche vom 08.07.2026)

### Gegenwart
- **Phase:** Infrastruktur-Setup
- **Meilenstein:** Zentrale Nervenbahn (Git + GitHub) live
- **Betrieb:** Gerade "eröffnet"

---

## 🎯 Ziel dieser Woche

**Fundament des Maklerbetrieb-Systems aufbauen:**
1. Geschäftsmodell & Use-Cases dokumentieren
2. Datenmodell skizzieren (Kunden, Policen, Provisionen, Makler)
3. Erste Architecture Decision Records (ADRs) treffen
4. UI/UX-Skizzen für Kernprozesse

---

## ✅ Abgeschlossen (diese Woche)

- [x] Git-Repository initialisiert
- [x] GitHub-Remote konfiguriert
- [x] **CLAUDE.md** geschrieben (Spielregeln als Maschinencode)
- [x] **STATUS.md Template** angelegt
- [x] Betriebsmodell verankert (3 Ebenen: Admin/Buchhaltung/Produktiv)

---

## 🔄 In Arbeit

- [x] Voice-Input Setup (Claude Desktop App bestätigt, Browser-Claude mit GitHub verlinkt)
- [ ] **Geschäftsanalyse** — Nutzer erzählt: Wie funktioniert Maklerbetrieb? (NÄCHSTER SCHRITT)
- [ ] **BETRIEB.md** — Betriebsmodell für Maklerbetrieb detaillieren
- [ ] **RESOURCE-POLICY.md** — Token/Budget-Strategie
- [ ] **Datenmodell v0.1** — Entities und Beziehungen

---

## 📋 Nächste Schritte (priorisiert)

### DIESE SESSION
1. Nutzer erzählt: Wie funktioniert ein Maklerbetrieb? (Domain-Knowledge)
   - Wer sind die Akteure?
   - Was ist der kritische Workflow?
   - Welche Schmerzen/Probleme?
2. Rollen-Definition (Makler, Admin, Prokurist, etc.)
3. Kern-Use-Cases aufschreiben

### FOLGE-SESSIONEN
4. Datenmodell → Entities, Relationships, Constraints
5. Erste Prototyp-UI für Hauptprozess
6. API-Spezifikation (wenn Web-App geplant)
7. Deployment-Strategie

---

## 🚨 Blockers & Offene Fragen

| Frage | Status | Zuständig | Notizen |
|-------|--------|-----------|---------|
| Welche Tech-Stack? (Web/Desktop/Hybrid) | ⏳ Klärt | Nutzer | Abhängig von Anforderung |
| Regulatorische Anforderungen? (Makler-Gesetze, Versicherungsrecht) | ⏳ Klärt | Nutzer | Sehr relevant für Go-Live |
| Kundenanzahl, Datenmenge, Performance-Ziele? | ⏳ Klärt | Nutzer | Bestimmt Architektur |

---

## 📊 Ressourcen-Verbrauch (Buchhaltung)

| Ressource | Budget | Verbraucht | Frei |
|-----------|--------|-----------|------|
| Kontext (Claude) | 100% | ~35% | 65% |
| Git-Commits | ∞ | 2 | ∞ |
| GitHub-Storage | ✓ | <1MB | ✓ |
| Tokens (Claude.ai) | ? | Minimal | ? |

---

## 👥 Betriebsrat (Verantwortlichkeiten)

| Rolle | Träger | Verantwortung |
|-------|--------|---------------|
| **Betriebsleiter** | Nutzer | Strategie, Entscheidungen, Ressourcen |
| **CTO / Architekt** | Claude Code | Technische Struktur, Code-Qualität |
| **Berater** | Claude.ai | Strategisches Denken, Komplexe Fragen |
| **Scribe** | Claude (diese Instanz) | Protokolle, STATUS.md, Kommunikation |

---

## 📝 Session-Protokolle (Chronologie)

### 2026-07-08 — Session 1: Infrastruktur-Setup
- **Dauer:** ~30 Min
- **Ziel:** Zentrale Nervenbahn aufbauen
- **Ergebnis:** ✓ Git + CLAUDE.md + STATUS.md live
- **Nächster Schritt:** Domain-Knowledge-Session zum Maklerbetrieb

---

## 🔗 Wichtige Verweise

- **Betriebskonzept:** → CLAUDE.md
- **Spielregeln:** → CLAUDE.md (Grundregeln, Session-Ritual)
- **Projekt-README:** → README.md
- **GitHub:** https://github.com/VTgit-hub-tippi/RennsteigFINANZ

---

## 📌 Hinweise für künftige Sessions

1. **Vor dem Start:** Diesen Status lesen, Git-Pull machen
2. **Während:** Neue Erkenntnisse/Blockers hier notieren, nicht im Chat vergessen
3. **Beim Beenden:** Diese Datei updaten, committen, pushen
4. **Kontextbudget:** Bei >70% → `/context-snapshot` vor Schluss

---

**Zuletzt aktualisiert:** 2026-07-08, 12:00 UTC+2  
**Nächste automatische Review:** Nach Phase 1 (Geschäftsmodell-Definition)
