# CLAUDE.md — Spielregeln für diesen Betrieb

> **Dies ist die zentrale Konventionsdatei.** Jede KI-Instanz (Claude Code, Claude.ai, Claude in anderen Tools) liest diese Datei zu Beginn einer Session. Sie definiert, wie wir gemeinsam als "Betrieb" arbeiten.

---

## 🏛️ Betriebsmodell

**Maklerbetrieb für Finanzmakler** — entwickelt nach dem Modell einer Polyklinik:
- Verschiedene Kompetenzen unter einem Dach (IT, Finanz, Admin, Produktentwicklung)
- Arbeitsteilig, gegenseitig unterstützend
- Interdisziplinarität als Standard, nicht Ausnahme
- "Einer für alle, alle für einen"

### Drei Betriebsebenen

1. **Administrativ** — Governance, Spielregeln, Schnittstellen
2. **Buchhaltung** — Ressourcen, Budget, Effizienz, Token-Management
3. **Produktiv** — Coding, Design, Testing, Dokumentation

---

## 🤝 Grundregeln

### Infrastruktur vor Inhalt
Bevor Code geschrieben wird: Struktur, Konventionen, Schnittstellen stehen fest.

### Idempotent & Reversibel
- Jede Aktion kann rückgängig gemacht werden
- Vor jeder Änderung: Status prüfen, nicht zweimal machen
- Git ist die Wahrheit, nicht der Chat-Verlauf

### Kontextbudget respektieren
- Token sind eine Ressource wie Geld in echtem Betrieb
- Mindestens Sonnet, bevorzugt Opus für komplexe Coding-Aufgaben
- Bei ~60-70% Kontext-Auslastung: `/context-snapshot` → Neustart → `/context-restore`
- Monitoring: regelmäßig `https://claude.ai/new#settings/usage` prüfen

### Quellen der Wahrheit
- **STATUS.md** — Laufender Stand, wer macht was, nächste Schritte
- **CLAUDE.md** (diese Datei) — Spielregeln, Konventionen
- **Git-History** — Jede Änderung ist nachvollziehbar
- **GitHub Issues/Projects** — Abstraktion, nicht das Repo selbst

### Gegenseitige Hilfe als Standard
- Jeder kann jeden um Unterstützung bitten
- "Nein" ist außer bei technischen Unmöglichkeiten nicht akzeptabel
- Kontinuierliches Lernen durch Zusammenarbeit

### Transparenz über Ebenen hinweg
- Alle Betriebsebenen haben Zugang zu Planung, Status, Entscheidungen
- Kein isoliertes Silodenken

---

## 📋 Session-Ritual

### Vor der Arbeit
1. Diese Datei (`CLAUDE.md`) lesen
2. `STATUS.md` lesen — wo sind wir, wer macht was
3. Git-Status prüfen: `git status`, evtl. `git pull`

### Während der Arbeit
- Arbeitsfolge sichtbar halten: Anforderungen → Spezifikation → Plan → Umsetzung → Tests
- Rückfragen aktiv einfordern
- Sub-Agents für Parallelisierung nutzen (nicht Sequenzialisierung)
- Kontextbudget im Blick

### Nach der Arbeit
1. Code/Dateien committen: `git add .` → `git commit -m "..."` → `git push`
2. `STATUS.md` aktualisieren
3. Offene Fragen/Blockers notieren
4. `/context-snapshot` vor Session-Ende (falls Kontext über 70%)

---

## 🛠️ Werkzeuge & Zugriff

| Werkzeug | Zugriff | Rolle | Git-Integration |
|----------|--------|-------|-----------------|
| VSCode (lokal) | ✓ | Editor | Native (CLI) |
| Claude Code | ✓ | Pair-Programming | Liest/schreibt Dateien |
| Claude.ai | ~ | Strategisches Denken, Protokolle | Upload nötig, STATUS.md per Hand |
| ChatGPT | ? | Optional (fallweise) | Extern, via export |
| GitHub | ✓ | Single Source of Truth | Primary |
| Homebrew | ✓ | Umgebung | Konfigurationsdateien im Repo |

---

## 📍 Projektstruktur (WIRD AUFGEBAUT)

```
/
├── CLAUDE.md              ← Diese Datei (Spielregeln)
├── STATUS.md              ← Laufendes Logbuch (wöchentlich)
├── README.md              ← Überblick, Was ist dieses Projekt
├── InitialSetup.md        ← Onboarding für neue Instanzen
├── BETRIEB.md             ← Betriebsmodell detailliert (kommt)
├── RESOURCE-POLICY.md     ← Token/Budget-Management (kommt)
├── src/                   ← Produktiver Code
│   ├── maklerbetrieb/     ← Kern-Domäne
│   └── ...
├── docs/                  ← Dokumentation, Architektur, Entscheidungen
│   ├── ARCHITEKTUR.md
│   ├── context-snapshot.md
│   └── ...
├── tests/                 ← Automatisierte Tests
├── .github/               ← GitHub Actions, Workflows
└── .git/                  ← Version Control
```

---

## 🎯 Sprache & Stil

- **Sprache:** Deutsch (fachlich präzise, kein Kauderwelsch)
- **Anrede:** Du (kollegial)
- **Fehler:** Tipp- und Rechtschreibfehler korrigieren vor dem Speichern
- **Protokolle:** Wörtliche Chats in STATUS.md nur nach Bereinigung

---

## 📞 Eskalation & Entscheidungen

- **Unklar?** Fragen, nicht raten. Rückfragen sind kein Zeichen von Schwäche.
- **Blockiert?** Sofort notieren in STATUS.md, nicht warten.
- **Ressourcen-Engpass?** Administrator (Nutzer) informieren, nicht verschweigen.

---

## ✅ Checkliste für neue Sessions

- [ ] Diese Datei (`CLAUDE.md`) gelesen
- [ ] `STATUS.md` gelesen
- [ ] `git pull` (um neueste Änderungen zu holen)
- [ ] Kontextbudget gecheckt (Sonnet/Opus-Modell?)
- [ ] Erste Aufgabe ist klar (was konkret tue ich in dieser Session?)

---

**Letzte Änderung:** 2026-07-08 (Infrastruktur-Setup)  
**Nächste Review:** Nach Phase 1 des Maklerbetrieb-Aufbaus
